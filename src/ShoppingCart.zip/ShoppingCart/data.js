export const data = [
    {name:'banana',weight:3,price:10},
    {name:'mango',weight:5,price:20},
    {name:'apple',weight:2,price:40},
    {name:'lemonade',weight:3,price:32},
    {name:'pineapple',weight:2,price:23},
    {name:'strawberry',weight:1,price:70},
]